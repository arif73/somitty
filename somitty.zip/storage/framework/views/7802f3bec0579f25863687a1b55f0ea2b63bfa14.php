<?php $__env->startSection('page_main_content'); ?>
<style type="text/css" media="screen">
.dataTables_filter{ float: right !important; }	
</style>
<div class="box">
    <div class="box-header">
        <h1 class="box-title">All Investments</h1>
    </div>

<section class="content">
    <div class="row">
            <div class="col-xs-12">
      <div class="box">
        <!-- /.box-header -->
        <div class="box-body">
        	<div class="row">
        		<div class="col-md-4"></div>
        		<div class="col-md-4" style="text-align: center;"><legend>Cash Out</legend></div>
        		<div class="col-md-4"></div>
        	</div>
            <div id="example1_wrapper" class="dataTables_wrapper form-inline dt-bootstrap">
                <table id="example1" class="table table-bordered table-hover dataTable text-center" role="grid" aria-describedby="example1_info">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Date</th>
                            <th>Purpose</th>
                            <th>Details</th>
                            <th>Amount</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                            
                    <tbody>
                        <?php $__currentLoopData = $investment_out; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $each): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($each->id); ?></td>
                            <td><?php echo e(Carbon\Carbon::parse($each->date)->toDateString()); ?></td>
                            <td><?php echo e($each->purpose); ?></td>
                            <td><?php echo e($each->details); ?></td>
                            <td><?php echo e($each->amount); ?></td>
                            <td><?php echo e($each->status == 1 ? 'Running' : 'Closed'); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                            
                </table>
            </div>
			<hr>
            <div class="row">
            	<div class="col-md-4"></div>
            	<div class="col-md-4" style="text-align: center;"><legend>Cash In</legend></div>
            	<div class="col-md-4"></div>
            </div>

            <div id="example2_wrapper" class="dataTables_wrapper form-inline dt-bootstrap">
                <table id="example2" class="table table-bordered table-hover dataTable text-center" role="grid" aria-describedby="example2_info">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Date</th>
                            <th>Purpose</th>
                            <th>Details</th>
                            <th>Amount</th>
                        </tr>
                    </thead>
                            
                    <tbody>
                        <?php $__currentLoopData = $investment_in; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $each1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($each1->id); ?></td>
                            <td><?php echo e(Carbon\Carbon::parse($each1->date)->toDateString()); ?></td>
                            <td><?php echo e($each1->purpose); ?></td>
                            <td><?php echo e($each1->details); ?></td>
                            <td><?php echo e($each1->amount); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                            
                </table>
            </div>
        </div>
        <!-- /.box-body -->
      </div>
      <!-- /.box -->
    </div>
    <!-- /.col -->
        </div>
</section>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>