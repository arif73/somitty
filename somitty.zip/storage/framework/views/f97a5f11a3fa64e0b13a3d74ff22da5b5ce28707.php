<?php $__env->startSection('page_main_content'); ?>
<script src="https://code.jquery.com/jquery-1.12.4.js" 
 ></script>

<div class="box">
    <div class="box-header">
        <h1 class="box-title">All Cash In</h1>
        <br>
        <br>
    


    <!-- Search --> 
  
   <form method="POST" action="<?php echo e(url('cash-in/generate')); ?>">
    <?php echo csrf_field(); ?>
     

    <div class="row">

    <div class="col-sm-1"> From </div> 
    <div class="col-sm-4">
         <!-- <label>From</label> -->
        <div data-provide="datepicker" class="input-group date"> 
            <input type="text" name="from_date" class="form-control" required=""> 
            <div class="input-group-addon"><span class="glyphicon glyphicon-th"></span>
            </div>
        </div>
    </div> 
    <div class="col-sm-1"> To
     </div> 
     <div class="col-sm-4">
        <!--  <label>To</label> -->
        <div data-provide="datepicker" class="input-group date">
            <input type="text" name="to_date" class="form-control" required=""> 
            <div class="input-group-addon">
                <span class="glyphicon glyphicon-th"></span>
            </div>
        </div>
    </div>
   

</div> 

    <br><br> <div class="row"><div class="col-md-4"></div> <div class="col-md-4"><button type="submit" class="btn btn-info " id="cashin">Generate Cash In</button></div> <div class="col-md-4"></div></div></form>

    </div>
</div>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\htdocs\somitty\resources\views/cash_in/index.blade.php ENDPATH**/ ?>