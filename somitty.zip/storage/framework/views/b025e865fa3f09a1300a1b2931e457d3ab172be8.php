<?php $__env->startSection('page_main_content'); ?>
<script src="https://code.jquery.com/jquery-1.12.4.js" 
integrity="sha256-Qw82+bXyGq6MydymqBxNPYTaUXXq7c8v3CwiYwLLNXU=" crossorigin="anonymous"></script>

<?php if(session('msg')): ?>
        <div class="alert alert-success alert-dismissible notify">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
            <h4><i class="icon fa fa-check"></i>Success!</h4>
            <?php echo e(session('msg')); ?>

        </div>
<?php endif; ?>
<?php if($errors->any()): ?>
	<div class="alert alert-danger alert-dismissible notify">
	    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
	    <h4><i class="icon fa fa-warning"></i>Error!</h4>
	    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php echo e($error); ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div>
<?php endif; ?>

<div class="box">
    <div class="box-header" style="text-align: center;">
        <h1 class="box-title">Add Cash Out</h1>
    </div>

<section class="content">
    <div class="row">
        <div class="col-xs-12">
	    	<div class="box">
	       		<div class="box-body">
					<form role="form" method="post" action="<?php echo e(url('/cash-out/store')); ?>">
						<?php echo csrf_field(); ?>
						<div class="box-body">

							<div class="form-group row">
								<div class="col-md-2"></div>
								<div class="col-md-2"> <label for="name">Select :</label> </div>
								<div class="col-md-5">
									<select id="select" name="member" class="form-control">
										<option value="">Select</option>
										<option value="members">Members</option>
										<option value="others">Others</option>
										
									</select>
								</div>
								<div class="col-md-3"></div>
							</div>


							<div class="form-group row members"  style="display: none;">
								<div class="col-md-2"></div>
								<div class="col-md-2"> <label for="name">Select Member :</label> </div>
								<div class="col-md-5">
									<select name="member" class="form-control">
										<option value="">Select</option>
										<?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<option value="<?php echo e($member->id); ?>"><?php echo e($member->name); ?></option>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</select>
								</div>
								<div class="col-md-3"></div>
							</div>

							<div class="form-group row">
								<div class="col-md-2"></div>
								<div class="col-md-2"> <label for="date">Date :</label> </div>
								<div class="col-md-5">
									<input type="date" name="date" value="<?php echo e(old('date')); ?>" class="form-control" required>
								</div>
								<div class="col-md-3"></div>
							</div>

							<div class="form-group row others"  style="display: none;">
								<div class="col-md-2"></div>
								<div class="col-md-2"> <label for="admistration">Admistration :</label> </div>
								<div class="col-md-5">
									<input type="number" name="admistration" value="<?php echo e(old('admistration')); ?>" class="form-control" >
								</div>
								<div class="col-md-3"></div>
							</div>

							<div class="form-group row others" style="display: none;">
								<div class="col-md-2"></div>
								<div class="col-md-2"> <label for="entertainment">Entertainment :</label> </div>
								<div class="col-md-5">
									<input type="number" name="entertainment" value="<?php echo e(old('entertainment')); ?>" class="form-control" >
								</div>
								<div class="col-md-3"></div>
							</div>							

							<div class="form-group row members"  style="display: none;">
								<div class="col-md-2"></div>
								<div class="col-md-2"> <label for="investment_withdraw">Investment Profit :</label> </div>
								<div class="col-md-5">
									<input type="number" name="investment_withdraw" value="<?php echo e(old('investment_withdraw')); ?>" class="form-control" >
								</div>
								<div class="col-md-3"></div>
							</div>

							<!-- <div class="form-group row">
								<div class="col-md-2"></div>
								<div class="col-md-2"> <label for="others">Others :</label> </div>
								<div class="col-md-5">
									<input type="number" name="others" value="<?php echo e(old('others')); ?>" class="form-control" required>
								</div>
								<div class="col-md-3"></div>
							</div> -->

						</div>
						<!-- /.box-body -->
						<div class="box-footer">
							<div class="form-group row">
								<div class="col-md-3"></div>
								<div class="col-md-1"></div>
								<div class="col-md-5">
									<button type="submit" class="btn btn-success btn-block">Add Cash Out</button>
								</div>
								<div class="col-md-3"></div>
							</div>
						</div>	
				
				</form>
	       		</div>
	      	</div>
	      
	    </div>
    </div>
</section>

</div>
<script type="text/javascript">
	$(document).ready(function(){
	    $('#select').on('change', function() {
	      if ( this.value == 'members')
	      {
	        $(".members").show();
	        $(".others").hide();
	      }
	      else if( this.value == 'others')
	      {
	        $(".others").show();
	        $(".members").hide();
	      
	      }
	      else {
	      	$(".others").hide();
	      	$(".members").hide();
	      	
	      }
	    });
	});
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\htdocs\somitty\resources\views/cash_out/create.blade.php ENDPATH**/ ?>