<!DOCTYPE html>
<html>

  <head>
    <?php echo $__env->make('includes.html_head', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->yieldContent('style'); ?>
  </head>


  <body class="hold-transition skin-blue sidebar-mini">
    <div class="wrapper">

        <?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('includes.main_menu', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper" style="min-height: 396px;">

            <section class="content">

                <?php echo $__env->yieldContent('page_main_content'); ?>

            </section>

        </div>

        <?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        
    </div>
        <?php echo $__env->make('includes.default_js', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <?php echo $__env->yieldContent('scripts'); ?>
  </body>

</html>
