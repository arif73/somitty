<?php $__env->startSection('page_main_content'); ?>

<?php if(session('msg')): ?>
        <div class="alert alert-success alert-dismissible notify">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
            <h4><i class="icon fa fa-check"></i>Success!</h4>
            <?php echo e(session('msg')); ?>

        </div>
<?php endif; ?>
<?php if($errors->any()): ?>
	<div class="alert alert-danger alert-dismissible notify">
	    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
	    <h4><i class="icon fa fa-warning"></i>Error!</h4>
	    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php echo e($error); ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div>
<?php endif; ?>

<div class="box">
    <div class="box-header">
        <h1 class="box-title">Admin List</h1>
    </div>

<section class="content">
    <div class="row">
            <div class="col-xs-12">
      <div class="box">
        <!-- /.box-header -->
        <div class="box-body">
            <div id="example1_wrapper" class="dataTables_wrapper form-inline dt-bootstrap">
                <table id="example1" class="table table-bordered table-hover dataTable text-center" role="grid" aria-describedby="example1_info">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Status</th>
                            <th>Change Password</th>

                        </tr>
                    </thead>
                            
                    <tbody>
                    	<?php $i = 0 ?>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                        	<td><?php echo e($user->id); ?></td>
                        	<td><?php echo e($user->name); ?></td>
                        	<td><?php echo e($user->email); ?></td>
                        	<td><?php echo e($user->status == 1 ? 'Active' : 'Inactive'); ?>

                        		<span>
                        			<a href="/change-status/<?php echo e($user->id); ?>" class="btn btn-warning btn-sm">Change</a>
                        		</span>
                        	</td>
                        	<td>
                        		<form action="/change-pass" method="post" class="form-group">
                        			<?php echo csrf_field(); ?>
                        			<input onmouseover="type = 'text'" onmouseout="type = 'password';" type="password" name="password" class="form-control input-sm showPass" required>
                        			<input type="hidden" name="id" value="<?php echo e($user->id); ?>">
                        			<button type="submit" class="btn btn-danger btn-sm">Change</button>
                        		</form>
                        	</td>
                        </tr>
                        <?php $i++ ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                            
                </table>
            </div>
        </div>
        <!-- /.box-body -->
      </div>
      <!-- /.box -->
    </div>
    <!-- /.col -->
        </div>
</section>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>