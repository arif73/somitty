

<?php if(session('msg')): ?>
        <div class="alert alert-success alert-dismissible notify">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
            <h4><i class="icon fa fa-check"></i>Success!</h4>
            <?php echo e(session('msg')); ?>

        </div>
<?php endif; ?>
<?php if($errors->any()): ?>
	<div class="alert alert-danger alert-dismissible notify">
	    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
	    <h4><i class="icon fa fa-warning"></i>Error!</h4>
	    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php echo e($error); ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div>
<?php endif; ?>

<div class="box">
    <div class="box-header" style="text-align: center;">
        <h1 class="box-title">Add an Admin</h1>
    </div>

<section class="content">
    <div class="row">
        <div class="col-xs-12">
	    	<div class="box">
	       		<div class="box-body">
					<form role="form" method="post" action="<?php echo e(route('user.store')); ?>">
						<?php echo csrf_field(); ?>
						<div class="box-body">

							<div class="form-group row">
								<div class="col-md-3"></div>
								<div class="col-md-1"> <label for="name">Name</label> </div>
								<div class="col-md-5">
									<input type="text" name="name" value="<?php echo e(old('name')); ?>" class="form-control" placeholder="Enter Name" required="">
								</div>
								<div class="col-md-3"></div>
							</div>

							<div class="form-group row">
								<div class="col-md-3"></div>
								<div class="col-md-1"> <label for="email">Email</label> </div>
								<div class="col-md-5">
									<input type="email" name="email" value="<?php echo e(old('email')); ?>" class="form-control" placeholder="Enter Email" required="">
								</div>
								<div class="col-md-3"></div>
							</div>

							<div class="form-group row">
								<div class="col-md-3"></div>
								<div class="col-md-1"> <label for="password">Password</label> </div>
								<div class="col-md-5">
									<input type="password" name="password" value="<?php echo e(old('password')); ?>" class="form-control" placeholder="Enter Password" required="">
								</div>
								<div class="col-md-3"></div>
							</div>
						</div>
						<!-- /.box-body -->
						<div class="box-footer">
							<div class="form-group row">
								<div class="col-md-3"></div>
								<div class="col-md-1"></div>
								<div class="col-md-5">
									<button type="submit" class="btn btn-success btn-block">Submit</button>
								</div>
								<div class="col-md-3"></div>
							</div>
						</div>	
				
				</form>
	       		</div>
	      	</div>
	      
	    </div>
    </div>
</section>

</div>

<?php /**PATH G:\xampp\htdocs\somitty\resources\views/user/create.blade.php ENDPATH**/ ?>