<!DOCTYPE html>
<html>
<head>
    <title>Reports</title>
    <link rel="stylesheet" type="text/css" href="<?php echo e(public_path('css/bootstrap.min.css')); ?>">
    <style type="text/css" media="screen">
        table.table-bordered{
            border:1px solid #222d32;
            margin-top:20px;
          }
        table.table-bordered > thead > tr > th{
            border:1px solid #222d32;
        }
        table.table-bordered > tbody > tr > td{
            border:1px solid #222d32;
        }
    </style>
</head>
<body style="background: #fff !important;">

    <?php
        $in_admistration = $premium = $fine = $profit = $total_credit = $out_admistration = $entertainment = $investment_withdraw  = $total_debit = $total_cash_in = $total_cash_out = 0;
    ?>

    <div class="row">
        <div class="col-md-6">
            <h1 class="box-title">Monthly Summary</h1>
            <strong style="color: #999;"><?php echo e(DateTime::createFromFormat('!m', $month)->format('F')); ?> <?php echo e($year); ?></strong>
        </div>
        <div class="col-md-6">
            <?php $image_path = '/logo.jpeg'; ?>
            <img src="<?php echo e(public_path() . $image_path); ?>" class="float-right" alt="" style="width: 10%; margin-right: 20px; float: right;">
        </div>
    </div>

    <h3 style="text-align: center;">Members Reposts</h3>
    <table class="table table-striped table-bordered text-center">
        <thead>
                        <tr>
                            <!-- <th colspan="2"></th> -->
                            <th colspan="8">Member Cash In</th>
                            <th colspan="6">Member Cash Out</th>
                        </tr>
                        <tr>
                            <th>#</th>
                            <th>Name</th>
                            <th>Premium</th>
                            <th>Admin</th>
                            <th>Fine</th>
                            <th>Profit</th>
                            <th>Date</th>
                            <th>Total Credit</th>
                            <th>Admin</th>
                            <th>Entertainment</th>
                            <th>Invest. Withdraw</th>
                          
                            <th>Total Debit</th>
                            <th>Comments</th>
                            <th>Balance</th>
                        </tr>
                    </thead>   
                    <tbody>
                        
                        <?php $__currentLoopData = $cashin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($report->member_id); ?></td>
                            <td><?php echo e($report->member->name); ?></td>
                            <td><?php echo e($report->premium); ?></td>
                            <td><?php echo e($report->in_admistration); ?></td>
                            <td><?php echo e($report->fine); ?></td>
                            <td><?php echo e($report->profit); ?></td>
                            <td><?php echo e(Carbon\Carbon::parse($report->date)->toDateString()); ?></td>
                            <td><?php echo e($report->total_credit); ?></td>
                            <td><?php echo e($report->out_admistration); ?></td>
                            <td><?php echo e($report->entertainment); ?></td>
                            <td><?php echo e($report->investment_withdraw); ?></td>
                           
                            <td><?php echo e($report->total_debit); ?></td>
                            <td><?php echo e($report->comments); ?></td>
                            <td>-</td>
                        </tr>
                        <?php
                            $in_admistration += $report->in_admistration;
                            $premium += $report->premium;
                            $fine += $report->fine;
                            $profit += $report->profit;
                            $total_credit += $report->total_credit;
                            $out_admistration += $report->out_admistration;
                            $entertainment += $report->entertainment;
                            $investment_withdraw += $report->investment_withdraw;
                           
                            $total_debit += $report->total_debit;
                        ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                         <?php $__currentLoopData = $cashout; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($report->member_id); ?></td>
                            <td><?php echo e($report->member->name); ?></td>
                            <td><?php echo e($report->premium); ?></td>
                            <td><?php echo e($report->in_admistration); ?></td>
                            
                            <td><?php echo e($report->profit); ?></td>
                            <td></td>
                            <td><?php echo e(Carbon\Carbon::parse($report->date)->toDateString()); ?></td>
                            <td><?php echo e($report->total_credit); ?></td>
                            <td><?php echo e($report->out_admistration); ?></td>
                            <td><?php echo e($report->entertainment); ?></td>
                            <td><?php echo e($report->investment_withdraw); ?></td>
                           
                            <td><?php echo e($report->total_debit); ?></td>
                            <td><?php echo e($report->comments); ?></td>
                            <td>-</td>
                        </tr>
                        <?php
                            $in_admistration += $report->in_admistration;
                            $premium += $report->premium;
                           
                            $profit += $report->profit;
                            $total_credit += $report->total_credit;
                            $out_admistration += $report->out_admistration;
                            $entertainment += $report->entertainment;
                            $investment_withdraw += $report->investment_withdraw;
                           
                            $total_debit += $report->total_debit;
                        ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                        

                       
                        <tr style="font-weight: bold;">
                            <td></td>
                            <td>Total</td>
                            <td><?php echo e($premium); ?></td>
                            <td><?php echo e($in_admistration); ?></td>
                            <td><?php echo e($fine); ?></td>
                            <td><?php echo e($profit); ?></td>
                            <td></td>
                            <td style="color: #22af28;"><?php echo e($total_credit); ?></td>
                            <td><?php echo e($out_admistration); ?></td>
                            <td><?php echo e($entertainment); ?></td>
                            <td><?php echo e($investment_withdraw); ?></td>
                           
                            <td style="color: red;"><?php echo e($total_debit); ?></td>
                            <td></td>
                            <td style="background: #222d32; color: #fff;"><?php echo e($total_credit - $total_debit); ?></td>
                        </tr>
                    </tbody>
                            
                </table>
            </div>

    <hr> 

    <div class="row">
        <div class="col-xs-12">
            <h3 style="text-align: center;">Investments Reports</h3>
            <table class="table table-striped table-bordered text-center">
                <thead>
                    <tr>
                        <th></th>
                        <th colspan="3">Investment Cash In</th>
                        <th colspan="5">Investment Cash Out</th>
                    </tr>
                    <tr>
                        <th>#</th>
                        <th>Invest. Name</th>
                        <th>Date</th>
                        <th>Amount</th>
                        <th>Invest. Name</th>
                        <th>Date</th>
                        <th>Amount</th>
                        <th>Status</th>
                        <th>Balance</th>
                    </tr>
                </thead>   
                <tbody>
                    <?php $__currentLoopData = $investments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $investment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($investment->id); ?></td>

                        <?php if($investment->purpose == 'cash_in'): ?>
                            <td><?php echo e(get_investment_by_id($investment->details)->details); ?></td>
                            <td><?php echo e(Carbon\Carbon::parse($investment->created_at)->toDateString()); ?></td>
                            <td><?php echo e($investment->amount); ?></td>
                            <td>-</td>
                            <td>-</td>
                            <td>0</td>
                            <td>-</td>
                            <td>-</td>

                            <?php $total_cash_in += $investment->amount; ?>
                        <?php else: ?>
                            <td>-</td>
                            <td>-</td>
                            <td>0</td>
                            <td><?php echo e($investment->details); ?></td>
                            <td><?php echo e(Carbon\Carbon::parse($investment->created_at)->toDateString()); ?></td>
                            <td><?php echo e($investment->amount); ?></td>
                            <td><?php echo e($investment->status == 1 ? 'Running' : 'Closed'); ?></td>
                            <td>-</td>
                            
                            <?php $total_cash_out += $investment->amount; ?>
                        <?php endif; ?>
                    </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                    
                    <tr style="font-weight: bold;">
                        <td></td>
                        <td>Total</td>
                        <td></td>
                        <td style="color: #22af28;"><?php echo e($total_cash_in); ?></td>
                        <td></td>
                        <td></td>
                        <td style="color: red;"><?php echo e($total_cash_out); ?></td>
                        <td></td>
                        <td style="background: #222d32; color: #fff;">
                            <?php echo e($total_cash_in - $total_cash_out); ?>

                        </td>
                    </tr>
                </tbody>
                        
            </table>
        </div>
    </div>

    <p style="font-weight: bold; color: #195005;">
       Total Balance : <?php echo e(($total_credit + $total_cash_in) - ($total_debit + $total_cash_out)); ?>

    </p> 

</body>
        


<?php /**PATH G:\xampp\htdocs\somitty\resources\views/reports/pdf.blade.php ENDPATH**/ ?>