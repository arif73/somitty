<?php $__env->startSection('page_main_content'); ?>
<script src="https://code.jquery.com/jquery-1.12.4.js" 
 ></script>

<div class="box">
    <div class="box-header">
        <h1 class="box-title">All Cash In</h1>
        <br>
        <br>
    


    <!-- Search --> 
  
   <form method="POST" action="<?php echo e(url('cash-in/generate')); ?>">
    <?php echo csrf_field(); ?>
     

    <div class="row">

    <div class="col-sm-1"> From </div> 
    <div class="col-sm-4">
         <!-- <label>From</label> -->
        <div data-provide="datepicker" class="input-group date"> 
            <input type="text" name="from_date" class="form-control" required=""> 
            <div class="input-group-addon"><span class="glyphicon glyphicon-th"></span>
            </div>
        </div>
    </div> 
    <div class="col-sm-1"> To
     </div> 
     <div class="col-sm-4">
        <!--  <label>To</label> -->
        <div data-provide="datepicker" class="input-group date">
            <input type="text" name="to_date" class="form-control" required=""> 
            <div class="input-group-addon">
                <span class="glyphicon glyphicon-th"></span>
            </div>
        </div>
    </div>
   

</div> 

    <br><br> <div class="row"><div class="col-md-4"></div> <div class="col-md-4"><button type="submit" class="btn btn-info " id="cashin">Generate Cash In</button></div> <div class="col-md-4"></div></div></form>

    </div>

<section class="content">
    <div class="row">
            <div class="col-xs-12">
      <div class="box">
        <!-- /.box-header -->
        <div class="box-body" >
            <div id="example1_wrapper" class="dataTables_wrapper form-inline dt-bootstrap table-responsive">
                <table id="example1" class="table table-bordered table-hover dataTable text-center" role="grid" aria-describedby="example1_info">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Name</th>
                            <th>Date</th>
                            <th>Premium</th>
                            <th>Admistration</th>
                            <th>Fine</th>
                            <th>Profit</th>
                            <th>Total Credit</th>
                            <th>Comments</th>
                        </tr>
                    </thead>
                            
                    <tbody>
                        <?php $__currentLoopData = $cash_in; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $each): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($each->id); ?></td>
                            <td><?php echo e($each->member->name); ?></td>
                            <td><?php echo e(Carbon\Carbon::parse($each->date)->format('d-M-Y')); ?></td>
                            <td><?php echo e($each->premium); ?></td>
                            <td><?php echo e($each->admistration); ?></td>
                            <td><?php echo e($each->fine); ?></td>
                            <td><?php echo e($each->profit); ?></td>
                            <td><?php echo e($each->total_credit); ?></td>
                            <td><?php echo e($each->comments); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                            
                </table>
            </div>
        </div>
        <!-- /.box-body -->
      </div>
      <!-- /.box -->
    </div>
    <!-- /.col -->
        </div>
</section>

</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\htdocs\somitty\resources\views/cash_in/generate.blade.php ENDPATH**/ ?>