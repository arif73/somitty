<?php $__env->startSection('page_main_content'); ?>

<?php
    $in_admistration = $premium = $fine = $profit = $total_credit = $out_admistration = $entertainment = $investment_withdraw = $others = $total_debit = $total_cash_in = $total_cash_out = 0;
?>

<div class="box">
    <div class="box-header">
        <h1 class="box-title">Monthly Summary</h1><br>
        <strong style="color: #999;"><?php echo e(DateTime::createFromFormat('!m', $month)->format('F')); ?> <?php echo e($year); ?></strong>
        <button onclick="reportToCsv('repots.csv')" class="btn btn-primary" style="float: right;">Save as CSV</button> 
        <form action="<?php echo e(url('/reports-pdf')); ?>" method="post" style="float: right; margin-right: 3px;">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="month" value="<?php echo e($month); ?>">
            <input type="hidden" name="year" value="<?php echo e($year); ?>">
            <button type="submit" class="btn btn-info">Save as PDF</button>
        </form>
    </div>

<section class="content">
    <div class="row">
            <div class="col-xs-12">
      <div class="box">
        <!-- /.box-header -->
        <div class="box-body">

            <div class="row">
                <div class="col-md-4"></div>
                <div class="col-md-4" style="text-align: center;"><legend>Members Reposts</legend></div>
                <div class="col-md-4"></div>
            </div>
            <?php if(count($cashin) > 0): ?>

            <div class="dataTables_wrapper form-inline dt-bootstrap table-responsive">
                <table class="table table-bordered table-hover text-center" role="grid">
                    <thead>
                        <tr>
                            <!-- <th colspan="2"></th> -->
                            <th colspan="8">Member Cash In</th>
                            <th colspan="7">Member Cash Out</th>
                        </tr>
                        <tr>
                            <th>#</th>
                            <th>Name</th>
                            <th>Premium</th>
                            <th>Admin</th>
                            <th>Fine</th>
                            <th>Profit</th>
                            <th>Date</th>
                            <th>Total Credit</th>
                            <th>Admin</th>
                            <th>Entertainment</th>
                            <th>Invest. Withdraw</th>
                          
                            <th>Total Debit</th>
                            <th>Comments</th>
                            <th>Balance</th>
                        </tr>
                    </thead>   
                    <tbody>
                        
                        <?php $__currentLoopData = $cashin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($report->member_id); ?></td>
                            <td><?php echo e($report->member->name); ?></td>
                            <td><?php echo e($report->premium); ?></td>
                            <td><?php echo e($report->in_admistration); ?></td>
                            <td><?php echo e($report->fine); ?></td>
                            <td><?php echo e($report->profit); ?></td>
                            <td><?php echo e(Carbon\Carbon::parse($report->date)->toDateString()); ?></td>
                            <td><?php echo e($report->total_credit); ?></td>
                            <td><?php echo e($report->out_admistration); ?></td>
                            <td><?php echo e($report->entertainment); ?></td>
                            <td><?php echo e($report->investment_withdraw); ?></td>
                           
                            <td><?php echo e($report->total_debit); ?></td>
                            <td><?php echo e($report->comments); ?></td>
                            <td>-</td>
                        </tr>
                        <?php
                            $in_admistration += $report->in_admistration;
                            $premium += $report->premium;
                            $fine += $report->fine;
                            $profit += $report->profit;
                            $total_credit += $report->total_credit;
                            $out_admistration += $report->out_admistration;
                            $entertainment += $report->entertainment;
                            $investment_withdraw += $report->investment_withdraw;
                           
                            $total_debit += $report->total_debit;
                        ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                         <?php $__currentLoopData = $cashout; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($report->member_id); ?></td>
                            <td><?php echo e($report->member->name); ?></td>
                            <td><?php echo e($report->premium); ?></td>
                            <td><?php echo e($report->in_admistration); ?></td>
                            
                            <td><?php echo e($report->profit); ?></td>
                            <td></td>
                            <td><?php echo e(Carbon\Carbon::parse($report->date)->toDateString()); ?></td>
                            <td><?php echo e($report->total_credit); ?></td>
                            <td><?php echo e($report->out_admistration); ?></td>
                            <td><?php echo e($report->entertainment); ?></td>
                            <td><?php echo e($report->investment_withdraw); ?></td>
                           
                            <td><?php echo e($report->total_debit); ?></td>
                            <td><?php echo e($report->comments); ?></td>
                            <td>-</td>
                        </tr>
                        <?php
                            $in_admistration += $report->in_admistration;
                            $premium += $report->premium;
                           
                            $profit += $report->profit;
                            $total_credit += $report->total_credit;
                            $out_admistration += $report->out_admistration;
                            $entertainment += $report->entertainment;
                            $investment_withdraw += $report->investment_withdraw;
                           
                            $total_debit += $report->total_debit;
                        ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                        

                       
                        <tr style="font-weight: bold;">
                            <td></td>
                            <td>Total</td>
                            <td><?php echo e($premium); ?></td>
                            <td><?php echo e($in_admistration); ?></td>
                            <td><?php echo e($fine); ?></td>
                            <td><?php echo e($profit); ?></td>
                            <td></td>
                            <td style="color: #22af28;"><?php echo e($total_credit); ?></td>
                            <td><?php echo e($out_admistration); ?></td>
                            <td><?php echo e($entertainment); ?></td>
                            <td><?php echo e($investment_withdraw); ?></td>
                           
                            <td style="color: red;"><?php echo e($total_debit); ?></td>
                            <td></td>
                            <td style="background: #222d32; color: #fff;"><?php echo e($total_credit - $total_debit); ?></td>
                        </tr>
                    </tbody>
                            
                </table>
            </div>
            <?php else: ?>
                <h1 style="color: red;">No Data Found!</h1>
            <?php endif; ?>


            <br> <hr> <br>

            <div class="row">
                <div class="col-md-4"></div>
                <div class="col-md-4" style="text-align: center;"><legend>Investment Summary</legend></div>
                <div class="col-md-4"></div>
            </div>

            <?php if(count($investments) > 0): ?>
            <div class="dataTables_wrapper form-inline dt-bootstrap table-responsive">
                <table class="table table-bordered table-hover text-center">
                    <thead>
                        <tr>
                            <th></th>
                            <th colspan="3">Investment Cash In</th>
                            <th colspan="4">Investment Cash Out</th>
                        </tr>
                        <tr>
                            <th>#</th>
                            <th>Investment Name</th>
                            <th>Date</th>
                            <th>Amount</th>
                            <th>Investment Name</th>
                            <th>Date</th>
                            <th>Amounts</th>
                            <th>Status</th>
                            <th>Balance</th>
                        </tr>
                    </thead>   
                    <tbody>
                        <?php $__currentLoopData = $investments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $investment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($investment->id); ?></td>

                            <?php if($investment->purpose == 'cash_in'): ?>
                                <td><?php echo e(get_investment_by_id($investment->details)->details); ?></td>
                                <td><?php echo e(Carbon\Carbon::parse($investment->created_at)->toDateString()); ?></td>
                                <td><?php echo e($investment->amount); ?></td>
                                <td>-</td>
                                <td>-</td>
                                <td>0</td>
                                <td>-</td>
                                <td>-</td>

                                <?php $total_cash_in += $investment->amount; ?>
                            <?php else: ?>
                                <td>-</td>
                                <td>-</td>
                                <td>0</td>
                                <td><?php echo e($investment->details); ?></td>
                                <td><?php echo e(Carbon\Carbon::parse($investment->created_at)->toDateString()); ?></td>
                                <td><?php echo e($investment->amount); ?></td>
                                <td><?php echo e($investment->status == 1 ? 'Running' : 'Closed'); ?></td>
                                <td>-</td>
                                
                                <?php $total_cash_out += $investment->amount; ?>
                            <?php endif; ?>
                        </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                        
                        <tr style="font-weight: bold;">
                            <td></td>
                            <td>Total</td>
                            <td></td>
                            <td style="color: #22af28;"><?php echo e($total_cash_in); ?></td>
                            <td></td>
                            <td></td>
                            <td style="color: red;"><?php echo e($total_cash_out); ?></td>
                            <td></td>
                            <td style="background: #222d32; color: #fff;">
                                <?php echo e($total_cash_in - $total_cash_out); ?>

                            </td>
                        </tr>
                    </tbody>
                            
                </table>

                <table>
                    <thead>
                        <tr>
                            <th>Total Bank Balance : </th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr style="font-weight: bold; color: #195005;">
                            <td>৳ <?php echo e(($total_credit + $total_cash_in) - ($total_debit + $total_cash_out)); ?></td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <?php else: ?>
                <h1 style="color: red;">No Data Found!</h1>
            <?php endif; ?>
        </div>
        <!-- /.box-body -->
      </div>
      <!-- /.box -->
    </div>
    <!-- /.col -->
        </div>
</section>

</div>

<script type="text/javascript">

    function downloadCSV(csv, filename) {
        var csvFile;
        var downloadLink;

        // CSV file
        csvFile = new Blob([csv], {type: "text/csv"});

        // Download link
        downloadLink = document.createElement("a");

        // File name
        downloadLink.download = filename;

        // Create a link to the file
        downloadLink.href = window.URL.createObjectURL(csvFile);

        // Hide download link
        downloadLink.style.display = "none";

        // Add the link to DOM
        document.body.appendChild(downloadLink);

        // Click download link
        downloadLink.click();
    }

    function reportToCsv(filename) 
    {
        var csv = [];
        var rows = document.querySelectorAll("table tr");

        for (var i = 0; i < rows.length; i++) 
        {
            var row = [], cols = rows[i].querySelectorAll("td, th");

            for (var j = 0; j < cols.length; j++)
                if (j == 6 || j == 7) {

                }
                else {
                    row.push(cols[j].innerText);
                }

            csv.push(row.join(","));
        }

        // Download CSV file
        downloadCSV(csv.join("\n"), filename);
    }
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\htdocs\somitty\resources\views/reports/index.blade.php ENDPATH**/ ?>